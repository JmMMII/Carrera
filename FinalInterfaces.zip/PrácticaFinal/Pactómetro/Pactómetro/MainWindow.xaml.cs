﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation.Peers;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup.Localizer;
using System.Windows.Media;
using System.Windows.Media.Converters;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Pactómetro.Clases;

namespace Pactómetro
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int constMargen = 60;
        VentanaSecundaria c;
        PactometroGestor p;
        ObservableCollection<Eleccion> elecciones = new ObservableCollection<Eleccion>();
        Eleccion actualSeleccionado = null;
        ObservableCollection<Partido> coalicion1 = new ObservableCollection<Partido>();
        ObservableCollection<Partido> coalicion2 = new ObservableCollection<Partido>();
        int tipoGrafico = 1;

        public MainWindow()
        {
            InitializeComponent();
            cargar();
        }

        public void cargar() {
            Eleccion aux = new Eleccion("Elecciones Generales", " 23/07/2023");
            aux.addPartido("PP", 136, Colors.Blue);
            aux.addPartido("PSOE", 122, Colors.Red);
            aux.addPartido("VOX", 33, Colors.Green);
            aux.addPartido("SUMAR", 31, Colors.Yellow);
            aux.addPartido("ERC", 7, Colors.Cyan);
            aux.addPartido("JUNTS", 7, Colors.PeachPuff);
            aux.addPartido("EH_BILDU", 6, Colors.Pink);
            aux.addPartido("EAJ_PNV", 5, Colors.BlueViolet);
            aux.addPartido("BNG", 1, Colors.MediumVioletRed);
            aux.addPartido("CCA", 1, Colors.Aquamarine);
            aux.addPartido("UPN", 1, Colors.DarkRed);

            elecciones.Add(aux);

            List<String> nombres = new List<String> { "PP", "PSOE", "VOX", "SUMAR", "ERC", "JUNTS", "EH_BILDU", "EAJ_PNV", "MASPAIS", "BNG", "CCA", "UPN", "CUP_PR", "OTROS" };
            List<int> numero = new List<int> { 120, 89, 52, 35, 13, 10, 8, 6, 5, 3, 2, 2, 1, 4 };
            List<Color> colores = new List<Color> { Colors.Blue, Colors.Red, Colors.Green, Colors.Yellow, Colors.Cyan, Colors.PeachPuff,Colors.Pink, Colors.BlueViolet, Colors.DarkGreen, Colors.MediumVioletRed, Colors.Aquamarine, Colors.DarkRed, Colors.Bisque, Colors.Coral};
            aux = new Eleccion("Elecciones Generales", "10/11/2019");
            aux.addPartidos(nombres, numero, colores);

            elecciones.Add(aux);

            nombres = new List<String> { "PP", "PSOE", "VOX", "UPL", "SY", "PODEMOS", "CS", "XAV" };
            numero = new List<int> { 31, 28, 13, 3, 3, 1, 1, 1 };
            colores = new List<Color> { Colors.Blue, Colors.Red, Colors.Green, Colors.Pink, Colors.Yellow, Colors.Aqua, Colors.DarkKhaki, Colors.DeepSkyBlue };
            aux = new Eleccion("Autonómicas Comunidad de Castilla y León", "14/02/2022");
            aux.addPartidos(nombres, numero, colores);

            elecciones.Add(aux);

            nombres = new List<String> { "PSOE", "PP", "CS", "PODEMOS", "VOX", "UPL", "XAV" };
            numero = new List<int> { 35, 29, 12, 2, 1, 1, 1 };
            colores = new List<Color> { Colors.Blue, Colors.Red, Colors.DarkKhaki, Colors.Aqua, Colors.Green, Colors.Pink, Colors.DeepSkyBlue };
            aux = new Eleccion("Autonómicas Comunidad de Castilla y León", "26/05/2019");
            aux.addPartidos(nombres, numero, colores);

            elecciones.Add(aux);

        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {

            //Calcula la altura del canvas según la altura total de la ventana quitando el margen,la altura del menu y la del titulo
            double altura = this.ActualHeight - tituloGrafico.ActualHeight - constMargen - menuOpciones.ActualHeight;
            //Para evitar que se produzca error se impide que la altura que se le asigna al canvas sea negatico
            if (altura > 0)
            canvasGraficos.Height = altura;
            //Se quita del ancho total, el margen
            canvasGraficos.Width = this.ActualWidth - constMargen;

            //Finalmente se llama a la función dibujar
            Dibujar();

        }

        private void MenuGestor_Click(object sender, RoutedEventArgs e)
        {
            if (c != null) return;

            c = new VentanaSecundaria(elecciones);
            c.Owner = this;
            c.GeneralSelectionChanged += General_SelectionChanged;
            c.Closed += C_closed;
            c.Show();

        }

        private void GestorPacto_Click(object sender, RoutedEventArgs e)
        {
            if (p != null) return;

            p = new PactometroGestor(coalicion1,coalicion2);
            p.Owner = this;
            p.CoalicionesChanged += CoalicionesChanged;
            p.Closed += P_closed;
            p.Show();
        }

        private void P_closed(object sender, EventArgs e)
        {
            p = null;
        }

        private void C_closed(object sender, EventArgs e)
        {
            c = null;
            this.Focus(); //Para evitar que la ventana principal se minimice
        }

        private void General_SelectionChanged(object sender, GeneralSelectionChanged e)
        {
            
            if (e.eleccion == null) {
                canvasGraficos.Children.Clear();
                tituloGrafico.Content = "";
                return;
            }

            //Asigna actualSeleccionado al la eleccion que está seleccionado en la ventana secundaria
            actualSeleccionado = e.eleccion;

            //Coalicion 1 y 2 son listas de elecciones para pactometro
            //Cuando se selecciona una nueva eleccion se les da valor
            coalicion1.Clear();
            coalicion2.Clear();
            for (int i = 0; i < actualSeleccionado.partidos.Count; i++)
            {
                if (i % 2 == 0)
                { coalicion1.Add(actualSeleccionado.partidos[i]); }
                else
                { coalicion2.Add(actualSeleccionado.partidos[i]); }
            }

            Dibujar();
        }

        private void CoalicionesChanged(object sender, CoalicionesChanged e)
        {
            //Función para actualizar el pactómetro cuando alguna de las coaliciones cambia
            if(tipoGrafico==3)
            Pactometro();
        }

        public void GraficoBarras() {

            //Limpio el canvasGraficos
            //Es redundante ya que lo hago en Dibujar también
            canvasGraficos.Children.Clear();

            //Pongo el título
            tituloGrafico.Content = actualSeleccionado.nombreEleccion;

            double xreal, xrealmin, xrealmax;
            double xpant, xpantmax, xpantmin;
            Label etiqueta;
            Rectangle barra;
            Line linea;
            int nDivision = 7;
            int alturaEtiqueta = 20;
            int i;

            xpantmax = canvasGraficos.Width;
            xpantmin = 0;

            xrealmin = 0;
            xrealmax = canvasGraficos.Width;

            //Altura maxima que puede tomar una barra, en realidad es el multiplo de 7 mayor más cercano del numero de escaños
            int alturaMaxBarra = (int)Math.Ceiling((double)actualSeleccionado.partidos[0].numeroEscanos / nDivision) * nDivision;

            //Calculo un ratio entre la altura disponible del canvas y el numero de escaños del partido que más tiene
            double razon = (canvasGraficos.Height - menuOpciones.Height - alturaEtiqueta*2) / alturaMaxBarra;

            for (i = 0; i <= nDivision; i++)
            {
                //Para colocar las lineas de division
                linea = new Line();
                linea.StrokeThickness = 3;
                linea.Stroke = Brushes.Red;
                linea.X1 = 0;
                //Altura del canvas - altura de menuOpciones - alturaEtiqueta (arriba y debajo)
                //Se suma alturaEtiqueta para que se muestre con el margen superior
                linea.Y1 = i * ((canvasGraficos.Height - menuOpciones.Height - alturaEtiqueta*2) / nDivision) + alturaEtiqueta;
                linea.X2 = 10;
                linea.Y2 = linea.Y1;
                canvasGraficos.Children.Add(linea);

                //Para colocar las etiquetas de las divisiones
                etiqueta = new Label();
                etiqueta.Content = (nDivision - i) * alturaMaxBarra / nDivision;
                etiqueta.FontSize = 10;
                etiqueta.Foreground = Brushes.Red;
                Canvas.SetTop(etiqueta, linea.Y2 - menuOpciones.Height);
                Canvas.SetLeft(etiqueta, linea.X1);

                canvasGraficos.Children.Add(etiqueta);
            }

            i = 1;
            foreach (Partido x in actualSeleccionado.partidos)
            {
                xreal = xrealmin + i * (xrealmax - xrealmin) / (actualSeleccionado.partidos.Count * 2 + 1);
                xpant = (xpantmax - xpantmin) * (xreal - xrealmin) / (xrealmax - xrealmin) + xpantmin;

                //Para colocar las etiquetas de los partidos
                etiqueta = new Label();
                etiqueta.Content = x.nombrePartido;
                Canvas.SetLeft(etiqueta, xpant);
                Canvas.SetTop(etiqueta, canvasGraficos.Height - menuOpciones.Height - alturaEtiqueta);
                canvasGraficos.Children.Add(etiqueta);

                //Para colocar las barras
                barra = new Rectangle();
                barra.ToolTip = x.numeroEscanos;
                barra.Fill = new SolidColorBrush(x.color);
                barra.Width = (xrealmax - xrealmin) / (actualSeleccionado.partidos.Count * 2 + 1);
                barra.Height = razon * x.numeroEscanos;
                Canvas.SetLeft(barra,xpant);
                Canvas.SetTop(barra, canvasGraficos.Height - barra.Height - menuOpciones.Height - alturaEtiqueta);
                canvasGraficos.Children.Add(barra);
                i += 2;
            }
        }

        public void GraficoBarrasMultiple() {
            //Limpio el canvasGrafico
            canvasGraficos.Children.Clear();

            double xreal, xrealmin, xrealmax;
            double xpant, xpantmax, xpantmin;
            int nDivision = 7;
            int alturaEtiqueta = 20;
            int i;
            float porcentajeMax = -1;
            Canvas leyenda = new Canvas();
            List<String> distPartidos = new List<String>();
            Dictionary<String, Partido> hashPartidos = new Dictionary<String, Partido>();
            Dictionary<Eleccion, Dictionary<String, Partido>> compElecciones = new Dictionary<Eleccion, Dictionary<String, Partido>>();
            Label etiqueta;
            Rectangle barra;
            Line linea;

            //Primero coloco el canvas que utilizare para colocar la leyenda
            leyenda.Background = Brushes.AliceBlue;
            leyenda.Height = (canvasGraficos.Height - menuOpciones.Height)/3;
            leyenda.Width = canvasGraficos.Width / 4;
            Canvas.SetTop(leyenda, 0);
            Canvas.SetLeft(leyenda, canvasGraficos.Width - leyenda.Width);
            canvasGraficos.Children.Add(leyenda);

            tituloGrafico.Content = actualSeleccionado.nombreEleccion;

            foreach (Eleccion aux in elecciones) {
                //Comprueba las elecciones del mismo tipo que actualSeleccionado
                if (actualSeleccionado.nombreEleccion==aux.nombreEleccion)
                {
                    //Comprueba que la eleccion tenga partidos, si tiene partidos calcula el que mayor porcentaje de escaños tiene
                    if(aux.partidos.Count > 0)
                    if (porcentajeMax < (float)aux.partidos.First().numeroEscanos / aux.escanos)
                        porcentajeMax = (float)aux.partidos.First().numeroEscanos / aux.escanos;

                    //Convierto la List<Partidos> de la eleccion en un hashmap con clave nombre del partido, por eficiencia
                    hashPartidos = new Dictionary<string, Partido>();
                    hashPartidos = aux.partidos.ToDictionary(Partido => Partido.nombrePartido);
                    //Añado el hahsmap de partidos a otro hashmap con clave eleccion
                    compElecciones.Add(aux, hashPartidos);

                    foreach (Partido temp in aux.partidos)
                    {
                        //Añado a la lista distPartidos todos los partidos diferentes de todas la elecciones del mismo tipo
                        if (!distPartidos.Contains(temp.nombrePartido))
                            distPartidos.Add(temp.nombrePartido);
                    }
                }
            }

            xpantmax = canvasGraficos.Width;
            xpantmin = 0;

            xrealmin = 0;
            xrealmax = canvasGraficos.Width;

            //Dato el porcentaje máximo, calculo su múltiplo de nDivision mayor más cercano
            porcentajeMax = (float)Math.Ceiling(porcentajeMax * 100 / nDivision) * nDivision;

            //Ratio entre altura disponible y el porcentaje maximo
            double razon = (canvasGraficos.Height - menuOpciones.Height - alturaEtiqueta * 2) / (porcentajeMax /100);

            for (i = 0; i <= nDivision; i++)
            {
                //Para colocar las lineas de division
                linea = new Line();
                linea.StrokeThickness = 3;
                linea.Stroke = Brushes.Red;
                linea.X1 = 0;
                //Altura del canvas - altura de menuOpciones - alturaEtiqueta (arriba y debajo)
                //Se suma alturaEtiqueta para que se muestre con el margen superior
                linea.Y1 = i * ((canvasGraficos.Height - menuOpciones.Height - alturaEtiqueta * 2) / nDivision) + alturaEtiqueta;
                linea.X2 = 10;
                linea.Y2 = linea.Y1;
                canvasGraficos.Children.Add(linea);

                //Para colocar las etiquetas de las divisiones
                etiqueta = new Label();
                etiqueta.Content = (nDivision - i) * porcentajeMax / nDivision + "%";
                etiqueta.FontSize = 10;
                etiqueta.Foreground = Brushes.Red;
                Canvas.SetTop(etiqueta, linea.Y2 - menuOpciones.Height);
                Canvas.SetLeft(etiqueta, linea.X1);

                canvasGraficos.Children.Add(etiqueta);
            }

            hashPartidos = new Dictionary<string, Partido>();
            Partido partido;
            Color relleno = new Color();
            double segmento = (xrealmax - xrealmin) / (distPartidos.Count * 2 + 1);
            int j = 0;
            i = 1;

            foreach (String nombreP in distPartidos) {
                xreal = xrealmin + i * segmento;
                xpant = (xpantmax - xpantmin) * (xreal - xrealmin) / (xrealmax - xrealmin) + xpantmin;
                j = 0;

                //Coloco las etiquetas de los partidos
                etiqueta = new Label();
                etiqueta.Content = nombreP;
                Canvas.SetLeft(etiqueta, xpant);
                Canvas.SetTop(etiqueta, canvasGraficos.Height - menuOpciones.Height - alturaEtiqueta);
                canvasGraficos.Children.Add(etiqueta);

                foreach (Eleccion eleccion in compElecciones.Keys) {

                    //Estos TryGetValue van a ser siempre exitosos
                    compElecciones.TryGetValue(eleccion, out hashPartidos);
                    if (hashPartidos.TryGetValue(nombreP, out partido)) {
                        xreal += j * segmento / compElecciones.Keys.Count;
                        xpant = (xpantmax - xpantmin) * (xreal - xrealmin) / (xrealmax - xrealmin) + xpantmin;

                        //Bajo la intensidad de los colores a medida que recorre las elecciones
                        relleno.ScR = (float)Math.Min(1, partido.color.ScR + 0.2 * j);
                        relleno.ScG = (float)Math.Min(1, partido.color.ScG + 0.2 * j);
                        relleno.ScB = (float)Math.Min(1, partido.color.ScB + 0.2 * j);
                        relleno.ScA = 1;
                        
                        //Colocar las barras
                        barra = new Rectangle();
                        barra.ToolTip = nombreP;
                        barra.Fill = new SolidColorBrush(relleno);
                        barra.Width = segmento / compElecciones.Keys.Count;
                        barra.Height = razon * partido.numeroEscanos / eleccion.escanos;
                        Canvas.SetLeft(barra, xpant);
                        Canvas.SetTop(barra, canvasGraficos.Height - barra.Height - menuOpciones.Height - alturaEtiqueta);
                        canvasGraficos.Children.Add(barra);
                    }
                    j++;
                }
                i += 2;
            }


            //El ancho de la leyenda se divide en 7 partes
            //La altura de divide segun el numero de elecciones a comparar
            double segmentoAlto = leyenda.Height / (compElecciones.Keys.Count * 2 + 1);
            relleno.ScA = 1;
            i = 0;
            //Para colocar la leyenda
            foreach (Eleccion eleccion in compElecciones.Keys) {
                barra = new Rectangle();
                barra.Width = (leyenda.Width / 7) * 2;
                barra.Height = segmentoAlto;

                relleno.R = (byte)Math.Min(255, 90 * (1 + 0.4 * i));
                relleno.G = (byte)Math.Min(255, 90 * (1 + 0.4 * i));
                relleno.B = (byte)Math.Min(255, 90 * (1 + 0.4 * i));

                barra.Fill = new SolidColorBrush(relleno);
                Canvas.SetTop(barra, segmentoAlto + segmentoAlto * i * 2);
                Canvas.SetLeft(barra, leyenda.Width / 7);
                leyenda.Children.Add(barra);

                etiqueta = new Label();
                etiqueta.Content = eleccion.fecha;
                Canvas.SetTop(etiqueta, segmentoAlto + segmentoAlto * i * 2);
                Canvas.SetLeft(etiqueta, (leyenda.Width / 7) * 3 +10);
                leyenda.Children.Add(etiqueta);

                i++;
            }

        }

        public void Pactometro() {

            canvasGraficos.Children.Clear();

            tituloGrafico.Content = actualSeleccionado.nombreEleccion;

            double xreal, yreal, xrealmin, xrealmax, yrealmin, yrealmax;
            double xpant, xetiqueta, ypant, xpantmax, xpantmin, ypantmin, ypantmax;
            Label etiqueta = new Label();
            Rectangle barra;
            Line linea;
            int alturaEtiqueta = 20;
            int contador = 0;

            xpantmax = canvasGraficos.Width;
            xpantmin = 0;
            ypantmax = 0;
            ypantmin = canvasGraficos.Height;

            xrealmin = 0;
            xrealmax = canvasGraficos.Width;
            yrealmin = canvasGraficos.Height;
            yrealmax = 0;

            double razon = (canvasGraficos.Height - menuOpciones.Height - alturaEtiqueta * 3) / actualSeleccionado.mayoria;

            linea = new Line();
            linea.StrokeThickness = 3;
            linea.Stroke = Brushes.Black;
            linea.X1 = 0;
            linea.Y1= 2*alturaEtiqueta;
            linea.X2 = canvasGraficos.Width;
            linea.Y2 = 2*alturaEtiqueta;
            canvasGraficos.Children.Add(linea);

            etiqueta = new Label();
            etiqueta.Content = actualSeleccionado.mayoria;
            Canvas.SetTop(etiqueta, alturaEtiqueta);
            Canvas.SetLeft(etiqueta, 0);
            canvasGraficos.Children.Add(etiqueta);

            //Si el partido con más escaños de la elección ya cumple con la mayoría
            if (actualSeleccionado.partidos.First().numeroEscanos > actualSeleccionado.mayoria) {
                xreal = xrealmin + (xrealmax - xrealmin) / 3; //Divido el ancho en 3 partes iguales
                xpant = (xpantmax - xpantmin) * (xreal - xrealmin) / (xrealmax - xrealmin) + xpantmin;

                etiqueta = new Label();
                etiqueta.Content = actualSeleccionado.partidos.First().numeroEscanos;
                etiqueta.FontSize = alturaEtiqueta;
                Canvas.SetTop(etiqueta, canvasGraficos.Height - menuOpciones.Height - alturaEtiqueta);
                Canvas.SetLeft(etiqueta, xpant);
                canvasGraficos.Children.Add(etiqueta);

                barra = new Rectangle();
                barra.ToolTip = actualSeleccionado.partidos.First().nombrePartido;
                barra.Width = (xpantmax - xpantmin) / 3;
                barra.Height = razon * actualSeleccionado.partidos.First().numeroEscanos;

                if(barra.Height > canvasGraficos.Height-alturaEtiqueta-menuOpciones.Height)
                    barra.Height = canvasGraficos.Height - alturaEtiqueta - menuOpciones.Height;  
                

                barra.Fill = new SolidColorBrush(actualSeleccionado.partidos.First().color);
                Canvas.SetTop(barra, canvasGraficos.Height - menuOpciones.Height - alturaEtiqueta - barra.Height);
                Canvas.SetLeft(barra, xpant);
                canvasGraficos.Children.Add(barra);
                return;
            }



            xreal = xrealmin + (xrealmax - xrealmin) / 5; //Divido el ancho en 5 partes iguales
            xpant = (xpantmax - xpantmin) * (xreal - xrealmin) / (xrealmax - xrealmin) + xpantmin;
            xreal = xrealmin + 2 * (xrealmax - xrealmin) / 5; //Colocar las etiquetas en la tercera columna
            xetiqueta = (xpantmax - xpantmin) * (xreal - xrealmin) / (xrealmax - xrealmin) + xpantmin;

            contador = 0;
            yreal = alturaEtiqueta;

            //Colocando los partidos de la primera coalicion
            foreach (Partido aux in coalicion1)
            {
                ypant = (ypantmin - ypantmax) * (yreal - yrealmin) / (yrealmax - yrealmin) + ypantmax - alturaEtiqueta;

                contador += aux.numeroEscanos;

                barra = new Rectangle();
                barra.DataContext = aux;
                barra.ToolTip = aux.nombrePartido;
                barra.Width = (xpantmax - xpantmin) / 5;
                barra.Height = razon * aux.numeroEscanos;
                barra.Fill = new SolidColorBrush(aux.color);
                barra.MouseLeftButtonDown += Rectangle_MouseLeftButtonDown;

                if (yreal + barra.Height > canvasGraficos.Height - menuOpciones.Height) { 
                    barra.Height = canvasGraficos.Height -menuOpciones.Height - yreal;
                    yreal = canvasGraficos.Height - menuOpciones.Height;
                }
                else 
                    yreal += barra.Height;

                if (barra.Height > 10) {
                    etiqueta = new Label();
                    etiqueta.FontSize = 10;
                    etiqueta.Content = aux.nombrePartido + " - " + aux.numeroEscanos;
                    Canvas.SetTop(etiqueta, ypant - alturaEtiqueta);
                    Canvas.SetLeft(etiqueta, xetiqueta);
                    canvasGraficos.Children.Add(etiqueta);
                }

                Canvas.SetTop(barra, ypant - barra.Height);
                Canvas.SetLeft(barra, xpant);

                canvasGraficos.Children.Add(barra);
            }

            etiqueta = new Label();
            etiqueta.Content = contador;
            etiqueta.FontSize = 15;
            Canvas.SetLeft(etiqueta, xpant);
            Canvas.SetTop(etiqueta, canvasGraficos.Height - menuOpciones.Height - alturaEtiqueta);
            canvasGraficos.Children.Add(etiqueta);

            xreal = xrealmin + 3 * (xrealmax - xrealmin) / 5; //Divido el ancho en 5 partes iguales
            xpant = (xpantmax - xpantmin) * (xreal - xrealmin) / (xrealmax - xrealmin) + xpantmin;
            xreal = xrealmin + 4 * (xrealmax - xrealmin) / 5; //Colocar las etiquetas en la tercera columna
            xetiqueta = (xpantmax - xpantmin) * (xreal - xrealmin) / (xrealmax - xrealmin) + xpantmin;

            yreal = alturaEtiqueta;
            contador = 0;

            //Colocar los partidos de la segunda coalición
            foreach (Partido aux in coalicion2)
            {
                ypant = (ypantmin - ypantmax) * (yreal - yrealmin) / (yrealmax - yrealmin) + ypantmax - alturaEtiqueta;


                contador += aux.numeroEscanos;

                barra = new Rectangle();
                barra.DataContext = aux;
                barra.ToolTip = aux.nombrePartido;
                barra.Width = (xpantmax - xpantmin) / 5;
                barra.Height = razon * aux.numeroEscanos;
                barra.Fill = new SolidColorBrush(aux.color);
                barra.MouseLeftButtonDown += Rectangle_MouseLeftButtonDown;

                if (yreal + barra.Height > canvasGraficos.Height - menuOpciones.Height)
                {
                    barra.Height = canvasGraficos.Height - menuOpciones.Height - yreal;
                    yreal = canvasGraficos.Height - menuOpciones.Height;
                }
                else
                    yreal += barra.Height;

                if (barra.Height > 10)
                {
                    etiqueta = new Label();
                    etiqueta.FontSize = 10;
                    etiqueta.Content = aux.nombrePartido + " - " + aux.numeroEscanos;
                    Canvas.SetTop(etiqueta, ypant - alturaEtiqueta);
                    Canvas.SetLeft(etiqueta, xetiqueta);
                    canvasGraficos.Children.Add(etiqueta);
                }

                Canvas.SetTop(barra, ypant - barra.Height);
                Canvas.SetLeft(barra, xpant);

                canvasGraficos.Children.Add(barra);
            }

            etiqueta = new Label();
            etiqueta.Content = contador;
            etiqueta.FontSize = 15;
            Canvas.SetLeft(etiqueta, xpant);
            Canvas.SetTop(etiqueta, canvasGraficos.Height - menuOpciones.Height - alturaEtiqueta);
            canvasGraficos.Children.Add(etiqueta);
        }

        public void Dibujar() {

            canvasGraficos.Children.Clear();
            tituloGrafico.Content = "";

            if (actualSeleccionado == null) return;
            if (actualSeleccionado.partidos.Count == 0) return;

            switch (tipoGrafico)
            {
                case 1:
                    GraficoBarras();
                    break;
                case 2:
                    GraficoBarrasMultiple();
                    break;
                case 3:
                    Pactometro();
                    break;
            }
        }

        private void Rectangle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //Evento para colocar los partidos en la primera coalicion o en la segunda, según corresponda
            Rectangle aux = (Rectangle)sender;
            if (coalicion1.Contains(aux.DataContext)) {
                coalicion2.Add((Partido)aux.DataContext);
                coalicion1.Remove((Partido)aux.DataContext);
            }
            else {
                coalicion1.Add((Partido)aux.DataContext);
                coalicion2.Remove((Partido)aux.DataContext);
            }
            Pactometro();
        }

        private void Barras_Click(object sender, RoutedEventArgs e)
        {
            tipoGrafico = 1;
            Dibujar();
        }

        private void Comparativo_Click(object sender, RoutedEventArgs e)
        {
            tipoGrafico = 2;
            Dibujar();
        }

        private void Pactometro_Click(object sender, RoutedEventArgs e)
        {
            tipoGrafico = 3;
            Dibujar();
        }
    }
}
