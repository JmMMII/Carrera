﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pactómetro
{
    /// <summary>
    /// Lógica de interacción para FormularioPartido.xaml
    /// </summary>

    public class NuevoPartidoEventArgs : EventArgs { 
    
        public String nombre { get; set; }
        public int cantidad { get; set; }
        public Color color { get; set; }

        public NuevoPartidoEventArgs(String nombre, int cantidad, Color color) { 
            this.nombre = nombre;
            this.cantidad = cantidad;
            this.color = color;
        }

    }

    public partial class FormularioPartido : Window
    {
        public event EventHandler<NuevoPartidoEventArgs> nuevoPartido;
        public String nombre { 
            get { return textBox_Nombre.Text; } 
            set { nombre = textBox_Nombre.Text; } 
        }
        public int cantidad { 
            get { return int.Parse(numericBox_Cantidad.Text); } 
            set { cantidad = int.Parse(numericBox_Cantidad.Text); } 
        }
        public Color color { 
            get { return (Color)colorPicker.SelectedColor; } 
            set { color = (Color)colorPicker.SelectedColor; } 
        }

        public FormularioPartido() {
            InitializeComponent();
            botonAceptar.Click += botonAceptar_Click;
        }

        public FormularioPartido(String nombre, int cantidad, Color color) {
            InitializeComponent();
            botonAceptar.Click += botonModificar_Click;
            textBox_Nombre.Text = nombre;
            numericBox_Cantidad.Text = cantidad.ToString();
            colorPicker.SelectedColor = color;
        }

        void OnNuevoPartido(String nombre, int cantidad, Color color) { 
            nuevoPartido.Invoke(this,new NuevoPartidoEventArgs(nombre, cantidad, color));
        }

        private void textBox_Nombre_GotFocus(object sender, RoutedEventArgs e)
        {
            etiquetaNombre.Foreground = Brushes.Black;
        }

        private void numericBox_Cantidad_GotFocus(object sender, RoutedEventArgs e)
        {
            etiquetaEscanos.Foreground = Brushes.Black;
        }

        private void colorPicker_GotFocus(object sender, RoutedEventArgs e)
        {
            etiquetaColor.Foreground = Brushes.Black;
        }

        private void botonAceptar_Click(object sender, RoutedEventArgs e)
        {
            Boolean mal = false;
            //Comprobación de campos
            if (string.IsNullOrWhiteSpace(textBox_Nombre.Text)) { etiquetaNombre.Foreground = Brushes.Red; mal = true; }
            if (string.IsNullOrWhiteSpace(numericBox_Cantidad.Text)) { etiquetaEscanos.Foreground = Brushes.Red; mal = true; }
            if (colorPicker.SelectedColor == null) { etiquetaColor.Foreground = Brushes.Red; mal = true; }
            if (mal) return; //No hace nada en caso de que haya algún campo vacío

            OnNuevoPartido(nombre, cantidad, color);
            //Vacio los campos
            textBox_Nombre.Text = "";
            numericBox_Cantidad.Text = "";
            colorPicker.SelectedColor = null;
        }

        private void botonCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void botonModificar_Click(object sender, RoutedEventArgs e)
        {
            Boolean mal = false;
            //Comprobación de campos
            if (string.IsNullOrWhiteSpace(textBox_Nombre.Text)) { etiquetaNombre.Foreground = Brushes.Red; mal = true; }
            if (string.IsNullOrWhiteSpace(numericBox_Cantidad.Text)) { etiquetaEscanos.Foreground = Brushes.Red; mal = true; }
            if (colorPicker.SelectedColor == null) { etiquetaColor.Foreground = Brushes.Red; mal = true; }
            if (mal) return; //No hace nada en caso de que haya algún campo vacío

            OnNuevoPartido(nombre, cantidad, color);
            //Vacio los campos
            textBox_Nombre.Text = "";
            numericBox_Cantidad.Text = "";
            colorPicker.SelectedColor = null;
            this.Close();
        }
    }
}
