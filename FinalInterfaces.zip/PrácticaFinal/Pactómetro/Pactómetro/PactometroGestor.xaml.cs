﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Pactómetro.Clases;

namespace Pactómetro
{
    public class CoalicionesChanged : EventArgs
    {
        public CoalicionesChanged() { }
    }

    public partial class PactometroGestor : Window
    {
        public event EventHandler<CoalicionesChanged> CoalicionesChanged;
        ObservableCollection<Partido> coalicion1 = new ObservableCollection<Partido>();
        ObservableCollection<Partido> coalicion2 = new ObservableCollection<Partido>();

        public PactometroGestor(ObservableCollection<Partido> partidos1, ObservableCollection<Partido> partidos2)
        {
            InitializeComponent();
            coalicion1 = partidos1;
            coalicion2 = partidos2;
            TablaCoalicion1.ItemsSource = coalicion1;
            TablaCoalicion2.ItemsSource = coalicion2;
        }

        private void Coalicion1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (TablaCoalicion1.SelectedItem == null) return;

            coalicion2.Add((Partido)TablaCoalicion1.SelectedItem);
            coalicion1.Remove((Partido)TablaCoalicion1.SelectedItem);

            //Avisa a la ventana principal que se han cambiado las coaliciones
            OnCoalicionesChanged();
        }

        private void Coalicion2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (TablaCoalicion2.SelectedItem == null) return;

            coalicion1.Add((Partido)TablaCoalicion2.SelectedItem);
            coalicion2.Remove((Partido)TablaCoalicion2.SelectedItem);

            //Avisa a la ventana principal que se han cambiado las coaliciones
            OnCoalicionesChanged();
        }

        void OnCoalicionesChanged() {
            CoalicionesChanged.Invoke(this, new CoalicionesChanged());
        }
    }
}
