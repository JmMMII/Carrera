﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Pactómetro.Clases;
using Xceed.Wpf.Toolkit.Core;

namespace Pactómetro
{
    /// <summary>
    /// Lógica de interacción para VentanaSecundaria.xaml
    /// </summary>

    public class GeneralSelectionChanged : EventArgs
    {
        public Eleccion eleccion { get; set; }

        public GeneralSelectionChanged(Eleccion eleccion) {
            this.eleccion = eleccion;
        }
    }

    public partial class VentanaSecundaria : Window
    {
        public event EventHandler<GeneralSelectionChanged> GeneralSelectionChanged;
        FormularioEleccion FormularioEleccion;
        FormularioPartido FormularioPartido;
        ObservableCollection<Eleccion> elecciones;

        public VentanaSecundaria(ObservableCollection<Eleccion> elecciones)
        {
            InitializeComponent();
            this.elecciones = elecciones;
            ListaGeneral.ItemsSource = elecciones;
            
        }

        //SelectionChanged
        void OnGeneralSelectionChanged(Eleccion e) {
            GeneralSelectionChanged.Invoke(this,new GeneralSelectionChanged(e));
        }
        
        private void General_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListaGeneral.SelectedItem != null)
            {
                botonDelElec.IsEnabled = true;
                botonAddPart.IsEnabled = true;
                botonModElec.IsEnabled = true;
                ListaDetallada.ItemsSource = elecciones[ListaGeneral.SelectedIndex].partidos;
            }
            else {
                botonDelElec.IsEnabled = false;
                botonAddPart.IsEnabled = false;
                botonModElec.IsEnabled= false;
                botonModPart.IsEnabled = false;

                // "Vacio" la lista detallada
                ListaDetallada.ItemsSource = null;
            }

            //Informa a la ventana principal que se ha cambiado la eleccion
            OnGeneralSelectionChanged((Eleccion)ListaGeneral.SelectedItem);
        }

        private void Detallada_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListaDetallada.SelectedItem != null) { 
                botonDelPart.IsEnabled = true; 
                botonModPart.IsEnabled= true;
            }
            else { 
                botonDelPart.IsEnabled = false;
                botonModPart.IsEnabled = false;
            }
        }

        //LostFocus

        private void ListaGeneral_LostFocus(object sender, RoutedEventArgs e)
        {
            botonDelElec.IsEnabled = false;
            botonModElec.IsEnabled = false;
        }

        private void ListaDetallada_LostFocus(object sender, RoutedEventArgs e)
        {
            botonDelPart.IsEnabled = false;
            botonModPart.IsEnabled = false;
        }

        //GotFocus

        private void ListaGeneral_GotFocus(object sender, RoutedEventArgs e)
        {
            if (ListaGeneral.SelectedItem != null)
            {
                botonDelElec.IsEnabled = true;
                botonAddPart.IsEnabled = true;
                botonModElec.IsEnabled = true;
            }
            else 
            { 
                botonDelElec.IsEnabled = false; 
                botonModElec.IsEnabled = false; 
            }
        }

        private void ListaDetallada_GotFocus(object sender, RoutedEventArgs e) {

            if (ListaDetallada.SelectedItem != null)
            {
                botonDelPart.IsEnabled = true;
                botonModPart.IsEnabled = true;
            }
            else 
            { 
                botonDelPart.IsEnabled = false;
                botonModPart.IsEnabled = false;
            }
        }

        //Borrar eleccion o partido

        private void botonDelElec_Click(object sender, RoutedEventArgs e)
        {
            if (ListaGeneral.SelectedItem != null)
            {

                IList selectedItems = ListaGeneral.SelectedItems;
                int contador = selectedItems.Count;
                
                for (int i = contador-1; i >= 0; i--) 
                    elecciones.Remove((Eleccion)selectedItems[i]);
            }
        }

        private void botonDelPart_Click(object sender, RoutedEventArgs e)
        {
            if (ListaDetallada.SelectedItem == null) return;
            if (ListaGeneral.SelectedItem == null) return;

            IList temp = ListaDetallada.SelectedItems;
            int contador = temp.Count;

            for (int i=contador-1; i >= 0; i--)
                elecciones[ListaGeneral.SelectedIndex].removePartido((Partido)temp[i]);

            ListaGeneral.Items.Refresh();
            OnGeneralSelectionChanged((Eleccion)ListaGeneral.SelectedItem);
        }

        //Añadir eleccion o partido

        private void botonAddPart_Click(object sender, RoutedEventArgs e)
        {
            if (ListaGeneral.SelectedItem == null) return;

            //Para evitar que se puedan abrir varias ventanas, y que unicamente pueda estar un formulario abierto
            if (FormularioPartido != null) return;
            if (FormularioEleccion != null) return;

            FormularioPartido = new FormularioPartido();

            FormularioPartido.nuevoPartido += nuevoPartido;
            FormularioPartido.Closed += formularioPartido_Closed;
            FormularioPartido.Owner = this;
            FormularioPartido.Show();

        }

        private void botonAddElec_Click(object sender, RoutedEventArgs e)
        {

            if (FormularioEleccion != null) return;
            if (FormularioPartido != null) return;

            FormularioEleccion = new FormularioEleccion();

            FormularioEleccion.nuevaEleccion += nuevaEleccion;
            FormularioEleccion.Closed += formularioEleccion_Closed;
            FormularioEleccion.Owner = this;
            FormularioEleccion.Show();
        }

        //Closed

        private void formularioEleccion_Closed(object sender, EventArgs e) {
            FormularioEleccion = null;
        }

        private void formularioPartido_Closed(object sender, EventArgs e) {
            FormularioPartido = null;
        }

        //Nueva eleccion o partido

        private void nuevaEleccion(object sender, NuevaEleccionEventArgs e) {
            Eleccion aux = new Eleccion(e.nombre, e.fecha);
            elecciones.Add(aux);

            if(ListaGeneral.SelectedItem != null)
            OnGeneralSelectionChanged((Eleccion)ListaGeneral.SelectedItem);
        }

        private void nuevoPartido(object sender, NuevoPartidoEventArgs e) {

            //Comprueba si hay algún elemento seleccionado
            if (ListaGeneral.SelectedItem == null) return;

            elecciones[ListaGeneral.SelectedIndex].addPartido(e.nombre, e.cantidad, e.color);

            ListaGeneral.Items.Refresh();
            ListaDetallada.ItemsSource = elecciones[ListaGeneral.SelectedIndex].partidos;

            OnGeneralSelectionChanged((Eleccion)ListaGeneral.SelectedItem);

        }

        //KeyDown

        private void ListaGeneral_KeyDown(object sender, KeyEventArgs e)
        {
            //Si no hay ningún item seleccionado no se hace nada
            if (ListaGeneral.SelectedItem == null) return; 

            switch (e.Key)
            {
                case Key.Delete:
                    IList selectedItems = ListaGeneral.SelectedItems;
                    int contador = selectedItems.Count;

                    for (int i = contador - 1; i >= 0; i--)
                        elecciones.Remove((Eleccion)selectedItems[i]);

                    break;
            }

        }

        private void ListaDetallada_KeyDown(object sender, KeyEventArgs e)
        {
            //Si no hay ningún item seleccionado no se hace nada
            if (ListaDetallada.SelectedItem == null) return;
            if (ListaGeneral.SelectedItem == null) return;

            switch (e.Key)
            {
                case Key.Delete:
                    IList temp = ListaDetallada.SelectedItems;
                    int contador = temp.Count;

                    for (int i = contador - 1; i >= 0; i--)
                        elecciones[ListaGeneral.SelectedIndex].removePartido((Partido)temp[i]);

                    ListaGeneral.Items.Refresh();

                    OnGeneralSelectionChanged((Eleccion)ListaGeneral.SelectedItem);
                    break;
            }
        }

        private void botonModElec_Click(object sender, RoutedEventArgs e)
        {
            if (FormularioEleccion != null) return;
            if (FormularioPartido != null) return;
            if (ListaGeneral.SelectedItem == null) return;

            Eleccion aux = (Eleccion) ListaGeneral.SelectedItem;
            FormularioEleccion = new FormularioEleccion(aux.nombreEleccion,aux.fecha);

            FormularioEleccion.nuevaEleccion += modificarEleccion;
            FormularioEleccion.Closed += formularioEleccion_Closed;
            FormularioEleccion.Owner = this;
            FormularioEleccion.Show();
        }

        private void modificarEleccion(object sender, NuevaEleccionEventArgs e)
        {
            if (ListaGeneral.SelectedItem == null) return;

            Eleccion aux = (Eleccion)ListaGeneral.SelectedItem;
            aux.nombreEleccion = e.nombre;
            aux.fecha = e.fecha;
            ListaGeneral.Items.Refresh();
            OnGeneralSelectionChanged((Eleccion)ListaGeneral.SelectedItem);
        }

        private void botonModPart_Click(object sender, RoutedEventArgs e)
        {
            if (ListaGeneral.SelectedItem == null) return;
            if (ListaDetallada.SelectedItem == null) return;
            Partido aux = (Partido)ListaDetallada.SelectedItem;
            //Para evitar que se puedan abrir varias ventanas, y que unicamente pueda estar un formulario abierto
            if (FormularioPartido != null) return;
            if (FormularioEleccion != null) return;

            FormularioPartido = new FormularioPartido(aux.nombrePartido,aux.numeroEscanos,aux.color);

            FormularioPartido.nuevoPartido += modificarPartido;
            FormularioPartido.Closed += formularioPartido_Closed;
            FormularioPartido.Owner = this;
            FormularioPartido.Show();
        }

        private void modificarPartido(object sender, NuevoPartidoEventArgs e)
        {
            //Comprueba si hay algún elemento seleccionado
            if (ListaGeneral.SelectedItem == null) return;
            if (ListaDetallada.SelectedItem == null) return;

            elecciones[ListaGeneral.SelectedIndex].removePartido((Partido)ListaDetallada.SelectedItem);
            elecciones[ListaGeneral.SelectedIndex].addPartido(e.nombre,e.cantidad,e.color);

            ListaGeneral.Items.Refresh();
            ListaDetallada.ItemsSource = elecciones[ListaGeneral.SelectedIndex].partidos;

            OnGeneralSelectionChanged((Eleccion)ListaGeneral.SelectedItem);
        }
    }
}
