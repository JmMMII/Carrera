﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Pactómetro.Clases
{
    public class Partido{ 
        public String nombrePartido { get; set; }
        public int numeroEscanos { get; set; }
        public Color color { get; set; }

        public Partido(String nombrePartido, int numeroEscanos, Color color) { 
        this.nombrePartido = nombrePartido;
        this.numeroEscanos= numeroEscanos;
        this.color = color;
        }
    }
    public class Eleccion
    {
        public String nombreEleccion { get; set; }
        public String fecha { get; set; }
        public int escanos { get; set; } = 0;
        public int mayoria { get; set; }
        public ObservableCollection<Partido> partidos { get; set; } = new ObservableCollection<Partido>();

        public Eleccion(String nombre, String fecha) {
            this.nombreEleccion = nombre;
            this.fecha = fecha;
        }

        public void addPartido(String nPartido, int nEscaños, Color color) {
            Partido aux = new Partido(nPartido,nEscaños,color);
            partidos.Add(aux);
            this.escanos += nEscaños;
            this.mayoria = this.escanos / 2 + 1; 
            sortPartidos();
        }

        public void addPartidos(List<String> nombrePartido, List<int> numeroEscaños, List<Color> colores) {
            Partido aux;
            if (nombrePartido.Count() == numeroEscaños.Count() && nombrePartido.Count() == colores.Count())
            {
                for (int i = 0; i < nombrePartido.Count(); i++)
                {
                    aux = new Partido(nombrePartido[i], numeroEscaños[i], colores[i]);
                    partidos.Add(aux);
                    this.escanos += numeroEscaños[i];
                }
                this.mayoria = this.escanos / 2 + 1;
            }
            sortPartidos();
        }

        public void removePartido(Partido partido) {
            
            partidos.Remove(partido);
            this.escanos -= partido.numeroEscanos;
            this.mayoria = this.escanos / 2 + 1;
        }

        public void sortPartidos() {

            List<Partido> partidosOrdenado = new List<Partido>(partidos);
            partidosOrdenado.Sort((left, right) => right.numeroEscanos.CompareTo(left.numeroEscanos));

            for (int i = 0; i < partidosOrdenado.Count; i++)
            {
                partidos.Move(partidos.IndexOf(partidosOrdenado[i]), i);
            }
        }

    }
}
