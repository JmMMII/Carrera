﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;

namespace Pactómetro.Clases
{
    internal class NumericBox : TextBox
    {
        public NumericBox() {
            this.PreviewTextInput += NumericBox_PreviewTextInput;
        }

        void NumericBox_PreviewTextInput(object sender,TextCompositionEventArgs e) {
            NumberFormatInfo numberFormatInfo = System.Globalization.CultureInfo.CurrentCulture.NumberFormat;
            String separador = numberFormatInfo.NumberDecimalSeparator;
            String signo = numberFormatInfo.NegativeSign;
            String caracter = e.Text;

            /*
            if (Char.IsDigit(e.Text[0])) { }
            else if (caracter == "\b") { // El \b es backspace, no sé para qué sirve }
                else e.Handled = true;
            */

            //Comprobamos si es un número
            if (Char.IsDigit(e.Text[0])) { } 
            else e.Handled = true; //Detenemos el enrutamiento
        }


    }
}
