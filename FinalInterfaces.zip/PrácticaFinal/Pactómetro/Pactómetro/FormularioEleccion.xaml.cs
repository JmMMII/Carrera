﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pactómetro
{
    /// <summary>
    /// Lógica de interacción para FormularioEleccion.xaml
    /// </summary>

    public class NuevaEleccionEventArgs : EventArgs{

        public String nombre { get; set; }
        public String fecha { get; set; }

        public NuevaEleccionEventArgs(string nombre, string fecha)
        {
            this.nombre = nombre;
            this.fecha = fecha;
        }

    }

    public partial class FormularioEleccion : Window
    {
        public event EventHandler<NuevaEleccionEventArgs> nuevaEleccion;
        public String nombreEleccion { get { return comboBox_Nombre.Text; } set { this.nombreEleccion = comboBox_Nombre.Text; } } //El setter habría que pensarlo
        public String fecha { get { return datePicker_Fecha.Text; } set { this.fecha = datePicker_Fecha.Text; } }
        
        public FormularioEleccion()
        {
            InitializeComponent();
            comboBox_Nombre.Items.Add("Elecciones Generales"); 
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Andalucía");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Aragón");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Asturias");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Islas Baleares");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Canarias");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Cantabria");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Castilla y León");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Castilla-La Mancha");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Cataluña");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Extremadura");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Galicia");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Madrid");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Murcia");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de La Rioja");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Navarra");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad del País Vasco");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de la Comunidad Valenciana");
            comboBox_Nombre.Items.Add("Autonómicas Ciudad Autónoma de Ceuta");
            comboBox_Nombre.Items.Add("Autonómicas Ciudad Autónoma de Melilla");
            botonAceptar.Click += botonAceptar_Click;
        }

        public FormularioEleccion(String nombre, String fecha)
        {
            InitializeComponent();
            comboBox_Nombre.Items.Add("Elecciones Generales");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Andalucía");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Aragón");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Asturias");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Islas Baleares");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Canarias");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Cantabria");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Castilla y León");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Castilla-La Mancha");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Cataluña");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Extremadura");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Galicia");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Madrid");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Murcia");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de La Rioja");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de Navarra");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad del País Vasco");
            comboBox_Nombre.Items.Add("Autonómicas Comunidad de la Comunidad Valenciana");
            comboBox_Nombre.Items.Add("Autonómicas Ciudad Autónoma de Ceuta");
            comboBox_Nombre.Items.Add("Autonómicas Ciudad Autónoma de Melilla");
            botonAceptar.Click += botonModificar_Click;
            comboBox_Nombre.Text = nombre;
            datePicker_Fecha.Text = fecha;
        }

        private void botonModificar_Click(object sender, RoutedEventArgs e)
        {
            Boolean mal = false;
            //Comprobación de campos
            if (string.IsNullOrWhiteSpace(comboBox_Nombre.Text)) { comboBox_Nombre.Background = Brushes.LightSalmon; mal = true; }
            if (string.IsNullOrWhiteSpace(datePicker_Fecha.Text)) { datePicker_Fecha.Background = Brushes.LightSalmon; mal = true; }
            if (mal) return; //No hace nada en caso de que haya algún campo vacío

            OnNuevaEleccion(nombreEleccion, fecha);
            //Vacio los campos
            comboBox_Nombre.Text = "";
            datePicker_Fecha.SelectedDate = null;
            this.Close();
        }

        void OnNuevaEleccion (String nombre, String fecha){
            nuevaEleccion.Invoke(this, new NuevaEleccionEventArgs(nombre, fecha));
        }


        private void botonAceptar_Click(object sender, RoutedEventArgs e)
        {
            Boolean mal = false;
            //Comprobación de campos
            if (string.IsNullOrWhiteSpace(comboBox_Nombre.Text)) { comboBox_Nombre.Background = Brushes.LightSalmon; mal = true; }
            if (string.IsNullOrWhiteSpace(datePicker_Fecha.Text)) { datePicker_Fecha.Background = Brushes.LightSalmon; mal = true; }
            if (mal) return; //No hace nada en caso de que haya algún campo vacío
            
            OnNuevaEleccion(nombreEleccion,fecha);
            //Vacio los campos
            comboBox_Nombre.Text = "";
            datePicker_Fecha.SelectedDate = null;
        }

        private void botonCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ComboBox_Nombre_GotFocus(object sender, RoutedEventArgs e)
        {
            comboBox_Nombre.Background = Brushes.White;
        }

        private void datePicker_Fecha_GotFocus(object sender, RoutedEventArgs e)
        {
            datePicker_Fecha.Background = Brushes.White;
        }
    }
}
