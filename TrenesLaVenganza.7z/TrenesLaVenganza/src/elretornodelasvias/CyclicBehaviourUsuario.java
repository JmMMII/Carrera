package elretornodelasvias;

import java.util.Scanner;

import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class CyclicBehaviourUsuario extends CyclicBehaviour {

	@Override
	public void action() {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		ACLMessage msg = new ACLMessage();
		
		int[] mensaje = new int[3];
		try {
			System.out.printf("Origen:\n");
			mensaje[0] = Integer.parseInt(scan.nextLine());
			
			//String mensaje=scan.nextLine();
			//mensaje += ",";
			//Utils.enviarMensaje(myAgent, "atajo", mensaje);
			
			System.out.printf("Destino:\n");
			mensaje[1] = Integer.parseInt(scan.nextLine());
			
			//mensaje=mensaje + scan.nextLine();
			//mensaje += ",";
			//Utils.enviarMensaje(myAgent, "atajo", mensaje);
			
			System.out.printf("Hora:\n");
			mensaje[2] = Integer.parseInt(scan.nextLine());
			
			//mensaje=mensaje + scan.nextLine();
			Utils.enviarMensaje(myAgent, "ruta","ontologiaRuta", mensaje);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			System.err.printf("Error número no válido...\n");
		}
		
	}


}
