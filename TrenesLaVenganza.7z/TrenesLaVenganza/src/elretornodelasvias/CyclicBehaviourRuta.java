package elretornodelasvias;

import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.lang.acl.UnreadableException;

public class CyclicBehaviourRuta extends CyclicBehaviour {

	@Override
	public void action() {
		// TODO Auto-generated method stub
		System.out.printf("Esperando solicitud...\n");
		int[] mensaje = new int[3];
		ACLMessage msg=this.myAgent.blockingReceive(MessageTemplate.and(MessageTemplate.MatchOntology("ontologiaRuta"), MessageTemplate.MatchPerformative(ACLMessage.REQUEST)));
			try {
				mensaje = (int[])msg.getContentObject();
			} catch (UnreadableException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println("Origen:"+mensaje[0]+"\nDestino:"+mensaje[1]+"\nHora"+mensaje[2]);
	}

}
