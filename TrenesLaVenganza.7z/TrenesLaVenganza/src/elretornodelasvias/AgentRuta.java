package elretornodelasvias;

import jade.content.lang.sl.SLCodec;
import jade.core.Agent;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;

public class AgentRuta extends Agent {
	
	protected void setup() {
		DFAgentDescription df = new DFAgentDescription();
		df.setName(getAID());
		ServiceDescription serv = new ServiceDescription();
		serv.setName("Ruta");
		serv.setType("ruta");
		serv.addOntologies("ontologiaRuta");
		serv.addLanguages(new SLCodec().getName());
		df.addServices(serv);
		
		try {
			DFService.register(this, df);
		} catch (FIPAException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		this.addBehaviour(new CyclicBehaviourRuta());
	}
}
