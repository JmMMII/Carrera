package elretornodelasvias;

import jade.core.behaviours.CyclicBehaviour;

public class CyclicBehaviourLinea extends CyclicBehaviour{

	@Override
	public void action() {
		// TODO Auto-generated method stub
		
	}

}
